#include <stdio.h>
#include <stdint.h>

/*
10100101 >> 7              1    1
10100101 >> 6             10    0
10100101 >> 5            101    1
10100101 >> 4           1010    0
10100101 >> 3          10100    0
10100101 >> 2         101001    1
10100101 >> 1        1010010    0
10100101 >> 0       10100101    1
*/
void print_bits(int8_t n) {
    for (int i = 7; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
    }
    printf("\n");
}

int main(void) {
    print_bits(0xa5); // 0b10100101
    return 0;
}
