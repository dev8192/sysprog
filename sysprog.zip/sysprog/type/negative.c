#include <stdio.h>
#include <stdint.h>
#include <limits.h>

void print_bits(int8_t n) {
    for (int i = 7; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
    }
    printf("\n");
}

void test() {
    printf("Zero\n");
    print_bits(0);

    printf("+1\n");
    print_bits(1);

    printf("All bits set (2⁸ - 1 = 255 unsigned)\n");
    print_bits(-1);

    printf("Max positive (01111111)\n");
    print_bits(127);

    printf("Min negative (10000000)\n");
    print_bits(-128);
}

// -x == ~x + 1
void test2() {
    int8_t x = 42;
    int8_t neg_x = -x;
    int8_t twos_comp = ~x + 1;
    
    printf("  x = %4d  -> bits: ", x); print_bits(x); printf("\n");
    printf(" ~x = %4d  -> bits: ", (int8_t)~x); print_bits((int8_t)~x); printf("\n");
    printf("~x+1 = %4d  -> bits: ", twos_comp); print_bits(twos_comp); printf("\n");
    printf(" -x  = %4d  -> bits: ", neg_x); print_bits(neg_x); printf("\n");
    printf("Identity holds: %s\n\n", (neg_x == twos_comp) ? "YES" : "NO");
}

void test3() {
    printf("Range asymmetry (8-bit signed):\n");
    printf("  Minimum value: %d\n", INT8_MIN);   // -128
    printf("  Maximum value: %d\n", INT8_MAX);   // +127
    printf("  Note: |MIN| = %d, |MAX| = %d → one extra negative value!\n\n",
           -INT8_MIN, INT8_MAX);
}

void test4() {
    // 4. Demonstrate wrap-around behavior (using unsigned to avoid UB)
    printf("Arithmetic wrap-around (using unsigned for safety):\n");
    uint8_t u = 255;  // 0b11111111
    printf("  255 (unsigned) + 1 = %u → interpreted as %d (signed)\n", 
           u + 1, (int8_t)(u + 1));
    u = 128;          // 0b10000000
    printf("  128 (unsigned) interpreted as %d (signed)\n", (int8_t)u);
}

int main(void) {
    test();    
    return 0;
}
