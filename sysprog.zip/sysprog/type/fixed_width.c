#include <stdint.h>
#include <stdio.h>

void test1() {
    printf("%zu\n", sizeof(int8_t));
    printf("%zu\n", sizeof(int16_t));
    printf("%zu\n", sizeof(int32_t));
    printf("%zu\n", sizeof(int64_t));
}

void test() {
    printf("%zu\n", sizeof(uint8_t));
    printf("%zu\n", sizeof(uint16_t));
    printf("%zu\n", sizeof(uint32_t));
    printf("%zu\n", sizeof(uint64_t));
}

int main() {
    test();
    return 0;
}
