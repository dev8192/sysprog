#include <stdio.h>
#include <stdbool.h>

void test() {
    _Bool var1 = 0.0;  printf("%d\n", var1);
    _Bool var2 = 0.1;  printf("%d\n", var2);
    _Bool var3 = -0.1; printf("%d\n", var3);
    _Bool var4 = 8;    printf("%d\n", var4);
}

void test2() {
    printf("'%zu'\n", sizeof(_Bool)); // 1
    printf("'%zu'\n", sizeof(bool)); // 1
    printf("'%d'\n", true); // 1
    printf("'%d'\n", false); // 0
}

int main() {
    test();
    return 0;
}
