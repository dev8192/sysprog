

#include <stdio.h>

int main() {
    printf("Hello World\n");
    puts("Hello World");
    return 0;
}
