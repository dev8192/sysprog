#include <stdio.h>
#include <stdint.h>

/*
    Bitwise AND
*/
void test1(void) {
    printf("%x\n", 0xa5); // 0b10100101
    printf("%x\n", 0xa5 & 0x0f); // 0b00000101
    printf("%x\n", 0xa5 & 0xf0); // 0b10100000
}

/*
    Bitwise OR
*/
void test2(void) {
    printf("%x\n", 0xa5); // 0b10100101
    printf("%x\n", 0xa5 | 0x0f); // 0b00001111
    printf("%x\n", 0xa5 | 0xf0); // 0b11110101
}

/*
    Bitwise NOT
*/
void test(void) {
    printf("%x\n", 0xa5);  // 00000000 00000000 00000000 10100101
    printf("%x\n", ~0xa5); // 11111111 11111111 11111111 01011010
}

int main(void) {
    test();
    return 0;
}
