#include <stdio.h>

typedef struct {
    int x, y;
} Point;

void print_point(Point p) {
    printf("Point: (%d, %d)\n", p.x, p.y);
}

int main(void) {
    print_point((Point){11, 22});
    print_point((Point){.y = 22, .x = 11});
    return 0;
}
