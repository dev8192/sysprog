#include <stdio.h>
#include <math.h>

void test(void) {
    printf("%x\n", 0xa5); // 0b10100101
    printf("%x\n", (int) (
        1 * pow(2, 7) + 1 * pow(2, 6) + 1 * pow(2, 5) + 1 * pow(2, 4) +
        1 * pow(2, 3) + 1 * pow(2, 2) + 1 * pow(2, 1) + 1 * pow(2, 0)
    )); // 0b11111111
    printf("%x\n", (int) (
        1 * pow(2, 7) + 0 * pow(2, 6) + 1 * pow(2, 5) + 0 * pow(2, 4) +
        0 * pow(2, 3) + 1 * pow(2, 2) + 0 * pow(2, 1) + 1 * pow(2, 0)
    )); // 0b11111111
}

int main(void) {
    test();
    return 0;
}
