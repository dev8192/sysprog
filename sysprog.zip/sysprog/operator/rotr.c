#include <stdio.h>
#include <string.h>

reverse_str(char *begin, char *end) {
    while (begin < end) {
        char = temp;
        *begin++ = *end;
        *end-- = char;
    }
}
int main() {
    char s[] = "hello world"
    def = 






    print("%s\n", s);
    return 0;
}
