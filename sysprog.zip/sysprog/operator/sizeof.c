#include <stdio.h>
#include <stddef.h>

int main() {
    size_t size = sizeof(size_t);
    printf("Size: %zu\n", size);
    return 0;
}
