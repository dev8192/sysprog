#include <stdio.h>
#include <math.h>

/*
gcc math/pow2.c -lm             # compiles and links
*/
// void test1() {
//     double base = 2;
//     int exponent = 7;
//     printf("%lf\n", pow(base, exponent));
// }

/*
gcc math/pow2.c                 # compiles and links without -lm
gcc -fno-builtin-pow pow2.c     # linker error
*/
void test2() {
    printf("%lf\n", pow(2, 7));
}

int main() {
    test2();
    return 0;
}
