#include <stdint.h>
#include <stdio.h>

int pow1(int base, int exponent){
    if (exponent == 0){
        return 1;
    }
    int result = 1;
    for (int i = 0; i < exponent; i++){
        result = result * base;
        // printf("%d\n", result);
    } 
    return result;
}

int main(){
    printf("%d\n", pow1(2, 0));
    printf("%d\n", pow1(2, 1));
    printf("%d\n", pow1(2, 5));
    printf("%d\n", 0x7FFFFFFF); // 2147483647
    return 0;
}
