#include <stdio.h>
#include <math.h>

int main() {
    double base, result;
    int exponent;
    printf("Enter the base number: ");
    scanf("%lf", &base);
    printf("Enter the exponent: ");
    scanf("%d", &exponent);
    printf("%lf\n", base);
    printf("%d\n", exponent);
    result = pow(base, exponent);
    printf("%.2lf ** %d = %.2lf\n", base, exponent, result);
    return 0;
}
