#include <stdio.h>
#include "main.h"

int main(void) {
    greet();
    return 0;
}

void greet(void) {
    printf("%s\n", MESSAGE);
}
