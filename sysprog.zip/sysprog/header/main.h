#ifndef MYHEADER_H
#define MYHEADER_H

#define MESSAGE "Hello from header!"

void greet(void);

#endif
