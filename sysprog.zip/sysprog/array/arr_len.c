#include <stdio.h>
#include <stdint.h>

void test1() {
    uint8_t buf1[] = {
        0xd4, 0x13, 0xcc, 0xcf, 0xe7, 0x79, 0x92, 0x10,
    };
    uint8_t buf2[] = {
        0xd4, 0x13, 0xcc, 0xcf,
    };
    uint8_t buf3[] = {
        0xd4, 0x13,
    };
    printf("%zu\n", sizeof(buf1));
    printf("%zu\n", sizeof(buf2));
    printf("%zu\n", sizeof(buf3));
}

void test() {
    uint32_t buf1[] = {
        0xd4, 0x13, 0xcc, 0xcf, 0xe7, 0x79, 0x92, 0x10,
    };
    uint32_t buf2[] = {
        0xd4, 0x13, 0xcc, 0xcf,
    };
    uint32_t buf3[] = {
        0xd4, 0x13,
    };
    printf("%zu %zu\n", sizeof(buf1), sizeof(buf1) / sizeof(uint32_t));
    printf("%zu %zu\n", sizeof(buf2), sizeof(buf2) / sizeof(uint32_t));
    printf("%zu %zu\n", sizeof(buf3), sizeof(buf3) / sizeof(uint32_t));
}

int main() {
    test();
    return 0;
}
