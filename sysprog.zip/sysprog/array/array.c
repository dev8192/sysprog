#include <stdio.h>
#include <stdint.h>

void print_hex(const uint8_t *buf) {
    printf("'%lx'\n", buf + 0); // 00007ffe e8bc9618
    printf("'%lx'\n", buf + 1); // 00007ffe e8bc9619
    printf("'%lx'\n", buf + 2);
    printf("'%lx'\n", buf + 3);
    printf("'%lx'\n", buf + 4);
    printf("'%lx'\n", buf + 5);
    printf("'%lx'\n", buf + 6);
    printf("'%lx'\n", buf + 7);

    // printf("'%x'\n", *(buf + 0));
    // printf("'%x'\n", *(buf + 1));
    // printf("'%x'\n", *(buf + 2));
    // printf("'%x'\n", *(buf + 3));
    // printf("'%x'\n", *(buf + 4));
    // printf("'%x'\n", *(buf + 5));
    // printf("'%x'\n", *(buf + 6));
    // printf("'%x'\n", *(buf + 7));
}

int main() {
    uint8_t buf[] = {
        0xd4, 0x13, 0xcc, 0xcf, 
        0xe7, 0x79, 0x92, 0x10,
    };
    print_hex(buf);
    return 0;
}
