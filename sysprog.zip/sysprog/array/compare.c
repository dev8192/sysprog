#include <stdio.h>
#include <stdint.h>

uint64_t arr1[] = {
    0x428a2f98d728ae22ULL, 
    0x7137449123ef65cdULL, 
    0xb5c0fbcfec4d3b2fULL, 
    0xe9b5dba58189dbbcULL,
};

uint64_t arr2[] = {
    0x428a2f98d728ae22ULL, 
    0x7137449123ef65cdULL, 
    0xb5c0fbcfec4d3b2fULL, 
    0xe9b5dba58189dbbcULL,
};

int main(){
    for (int i = 0; i<(sizeof(arr1)/sizeof(uint64_t)); i++) {
        if (arr1[i] != arr2[i]){
            printf("%lx\n", arr1[i]);
            printf("%lx\n", arr2[i]);
            return 0;
        }
    };
    printf("arr1 == arr2\n");
    return 0;
}

