#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

bool compare_arrays(uint64_t *arr1, size_t sz1, uint64_t *arr2, size_t sz2) {
    if (sz1 != sz2) {
        return false;
    }
    for (int i = 0; i < sz1; i++) {
        if (arr1[i] != arr2[i]){
            printf("%lx\n", arr1[i]);
            printf("%lx\n", arr2[i]);
            return false;
        }
    };
    return true;
}

int main(){
    uint64_t arr1[] = {
        0x428a2f98d728ae22ULL, 
        0x7137449123ef65cdULL, 
        0xb5c0fbcfec4d3b2fULL, 
        0xe9b5dba58189dbbcULL,
    };
    size_t sz1 = sizeof(arr1) / sizeof(uint64_t);
    uint64_t arr2[] = {
        0x428a2f98d728ae22ULL,
        0x7137449123ef65cdULL,
        0xb5c0fbcfec4d3b2fULL,
        0xe9b5dba58189dbbcULL,
        // 0xe8b5dba58189dbbcULL,
    };
    size_t sz2 = sizeof(arr2) / sizeof(uint64_t);
    printf("arr1 %s arr2\n", compare_arrays(arr1, sz1, arr2, sz2) ? "==" : "!=");
    return 0;
}

