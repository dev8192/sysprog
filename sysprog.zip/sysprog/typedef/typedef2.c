#include <stdio.h>

// include\crypto\evp.h
struct evp_md_st {
    int block_size;
};

// include\openssl\types.h
typedef struct evp_md_st EVP_MD;

int EVP_MD_get_block_size(const EVP_MD *md)
{
    if (md == NULL) {
        // ERR_raise(ERR_LIB_EVP, EVP_R_MESSAGE_DIGEST_IS_NULL);
        return -1;
    }
    return md->block_size;
}

int main() {
    EVP_MD md = {333};
    int j = EVP_MD_get_block_size(&md);
    printf("%d\n", j);
}
