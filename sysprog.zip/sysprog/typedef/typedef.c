
#include <stdio.h>

typedef int i32;
i32 main() {
    i32 num1 = 10;
    i32 num2 = 25;
    printf("%d\n", num1 + num2);
    return 0;
}
