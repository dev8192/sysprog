#include <stdio.h>
#include <stdint.h>

void test() {
    uint8_t buf[] = {
        0xd4, 0x13, 0xcc, 0xcf, 0xe7, 0x79, 0x92, 0x10, 
        0x76, 0xcf, 0x5d, 0x0b, 0x09, 0x95, 0x4e, 0x76, 
    };
    for (int i = 0; i < sizeof(buf); i++)
        printf("%02x", buf[i]);
    printf("\n");
}

int main() {
    test();
    return 0;
}
