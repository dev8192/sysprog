#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <stdlib.h>

void test1() {
    char dst[] = "aaaaaaaaaaaaaaaa";
    char src[] = "bbbbbbbb";
    memcpy(dst, src, 8);
    printf("'%s'\n", dst);
}

void test2() {
    char dst[] = "aaaaaaaaaaaaaaaa";
    char src[] = "bbbbbbbb";
    memcpy(dst, src, sizeof src);
    printf("'%s'\n", dst);
    for (int i = 0; i < sizeof(dst); i++){
        printf("'%d' ", dst[i]);
    }
    printf("\n");
}

void test3() {
    int *p = malloc(3 * sizeof(int));
    int arr[3] = {1, 2, 3};
    memcpy(p, arr, 3 * sizeof(int));
    for (int i = 0; i < 3; i++){
        printf("'%d' ", p[i]);
    }
    printf("\n");
}

void test() {
    char dst[] = "aaaaaaaaaaaaaaaa";
    char src[] = "bbbbbbbb";
    memcpy(dst + 8, src, 8);
    printf("'%s'\n", dst);
}

int main() {
    test();
    return 0;
}
