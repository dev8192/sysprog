#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void test1() {
    const char *fruits[] = {"apple", "banana", "cherry"};
    int fruit_count = sizeof(fruits) / sizeof(fruits[0]);
    for (int i = 0; i < fruit_count; i++) {
        printf("%d '%s'\n", i, fruits[i]);
    }
}

void test2() {
    const char *fruits[3];
    fruits[0] = "apple";
    fruits[1] = "banana";
    fruits[2] = "kiwi";
    int fruit_count = sizeof(fruits) / sizeof(fruits[0]);
    for (int i = 0; i < fruit_count; i++) {
        printf("%d '%s'\n", i, fruits[i]);
    }
}

void test() {
    const char *fruits[3];
    const char *str = "one two three";
    char data[16];
    strcpy(data, str);
    fruits[0] = data;
    data[3] = '\0';
    fruits[1] = data + 4;
    data[7] = '\0';
    fruits[2] = data + 8;
    data[13] = '\0';
    int fruit_count = sizeof(fruits) / sizeof(fruits[0]);
    for (int i = 0; i < fruit_count; i++) {
        printf("%d '%s'\n", i, fruits[i]);
    }
}

int main() {
    test();
    return 0;
}
