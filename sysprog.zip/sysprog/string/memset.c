#include <stdio.h>
#include <string.h>

int main() {
    char str[] = "aaaaaaaa";
    puts(str);
    memset(str,'b', 4);
    puts(str);
}
