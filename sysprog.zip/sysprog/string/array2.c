#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void test2() {
    char colors[3][10] = {"red", "green", "blue"};
    
    printf("\n=== Method 2: 2D char array (modifiable) ===\n");
    for (int i = 0; i < 3; i++) {
        printf("colors[%d] = \"%s\"\n", i, colors[i]);
    }
    
    // ✅ Safe to modify individual characters:
    colors[0][0] = 'R';  // "red" → "Red"
    printf("Modified: colors[0] = \"%s\"\n", colors[0]);
    
    // ✅ Safe to overwrite entire string (within size limit):
    strcpy(colors[1], "yellow");  // "green" → "yellow"
    printf("Modified: colors[1] = \"%s\"\n", colors[1]);
}

void test3() {
    // METHOD 3: Dynamic allocation (advanced)
    // Array of pointers to heap-allocated strings
    char *animals[2];
    animals[0] = malloc(6 * sizeof(char));  // "cat\0" needs 4 chars, + safety margin
    animals[1] = malloc(7 * sizeof(char));
    
    strcpy(animals[0], "cat");
    strcpy(animals[1], "dog");
    
    printf("\n=== Method 3: Dynamically allocated strings ===\n");
    for (int i = 0; i < 2; i++) {
        printf("animals[%d] = \"%s\"\n", i, animals[i]);
    }
    
    // ✅ Safe to modify:
    animals[0][0] = 'b';  // "cat" → "bat"
    printf("Modified: animals[0] = \"%s\"\n", animals[0]);
    
    // Cleanup
    free(animals[0]);
    free(animals[1]);
}

int main() {
    test();
    return 0;
}
