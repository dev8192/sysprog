#include <stdio.h>

void reverse_string(char *str) {
    while(*str) {
        printf("%c\n", *str);
        str++;
    }
}

int main(void) {
    char buf[] = "hello";
    reverse_string(buf);
    return 0;
}
