#include <stdio.h>
#include <string.h>
#include <stdint.h>

void test1() {
    const char* name = "Alice";
    printf("%zu\n", strlen(name));
}

void test2() {
    const char* name = "Alice";
    printf("'%s'\n", name);
}

void test3() {
    uint8_t name[6];
    // char name[6];
    name[0] = 65;
    name[1] = 108;
    name[2] = 105;
    name[3] = 99;
    name[4] = 101;
    name[5] = 0;
    printf("'%s'\n", name);
}

void test() {
    char name[6];
    name[0] = 'A';
    name[1] = 'l';
    name[2] = 'i';
    name[3] = 'c';
    name[4] = 'e';
    name[5] = '\0';
    printf("'%s'\n", name);
}

int main() {
    test();
    return 0;
}

