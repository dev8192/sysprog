#include <stdio.h>
#include <string.h>

int main() {
    const char* name = "Alice";
    printf("%zu\n", strlen(name));
    return 0;
}

