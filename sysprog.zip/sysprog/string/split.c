#include <stdio.h>
#include <string.h>

int split_func1(char **result, const char *str){
    int idx = 0;
    char word[64];
    char *word_ptr = word;
    for (int i = 0; i < strlen(str); i++){
        if (str[i] == ' '){
            result[idx] = word;
            word_ptr = word;
            idx++;
        } else{
            *word_ptr++ = str[i];
        }
    }
    if(word_ptr > word){
        result[idx] = word;
    }
    return idx;
}

int split_func(char **result, char *str){
    int idx = 0;
    int len = strlen(str);
    char *word_start = str;
    int i = 0;
    for (; i < len; i++){
        if (str[i] == ' '){
            str[i] = '\0';
            result[idx] = word_start;
            word_start = str + i + 1;
            printf("'%s'\n", result[idx]);
            idx++;
        }
    }
    str[i] = '\0';
    result[idx] = word_start;
    idx++;
    return idx;
}

void print_mem(char **ptr, int count) {
    for (int i = 0; i < count; i++){
        printf("%p ", ptr[i]);
    }
    printf("\n");
}

int main(){
    char *result[8];
    const char *str = "one two three";
    char data[128];
    printf("%p\n", data);
    strcpy(data, str);
    print_mem(result, 8);
    int count = split_func(result, data);
    print_mem(result, 8);
    printf("%d\n", count);
    for (int i = 0; i < count; i++){
        printf("'%s'\n", result[i]);
    }
}
