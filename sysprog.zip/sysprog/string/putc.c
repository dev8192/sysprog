#include <stdio.h>

void test1() {
    putc(104, stdout);
    putc(101, stdout);
    putc(108, stdout);
    putc(108, stdout);
    putc(111, stdout);
    putc(33, stdout);
    putc(10, stdout);
}

void test2() {
    putchar(104);
    putchar(101);
    putchar(108);
    putchar(108);
    putchar(111);
    putchar(33);
    putchar(33);
    putchar(10);
}

void test() {
    putchar('h');
    putchar('e');
    putchar('l');
    putchar('l');
    putchar('o');
    putchar('!');
    putchar('!');
    putchar('!');
    putchar('\n');
}

int main() {
    test();
    return 0;
}
