#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void test() {
    char str1[] = "Hello";
    char str2[20] = "World";
    printf("str1: %s\n", str1);
    printf("str2: %s\n", str2);
}

void test() {
    char str3[50];
    printf("\nEnter your name: ");
    fgets(str3, sizeof(str3), stdin);
    str3[strcspn(str3, "\n")] = '\0';
    printf("Hello, %s!\n", str3);
}

void test() {
    char str1[] = "Hello";
    char str4[100];
    strcpy(str4, str1);
    printf("'%s'\n", str4);
    
    strncpy(str4, "Safe copy example", sizeof(str4) - 1);
    str4[sizeof(str4) - 1] = '\0'; // Ensure null termination
    printf("After safe copy: %s\n", str4);
}

void test() {
    const char *str1 = "Hello";
    const char *str2 = "World";
    char str4[100];
    strcpy(str4, str1);
    strcat(str4, " ");
    strcat(str4, str2);
    printf("Concatenated string: %s\n", str4);
    
    strcpy(str4, "Safe ");
    strncat(str4, "concatenation", sizeof(str4) - strlen(str4) - 1);
    printf("Safe concatenation: %s\n", str4);
}

void test() {
    const char *str1 = "Hello";
    const char *str2 = "World";
    int result = strcmp(str1, "Hello");
    printf("strcmp('%s', 'Hello') = %d\n", str1, result);
    
    result = strcmp(str1, str2);
    printf("strcmp('%s', '%s') = %d\n", str1, str2, result);
    
    result = strncmp(str1, "Hel", 3);
    printf("strncmp('%s', 'Hel', 3) = %d\n", str1, result);
}

void test() {
    char str4[100];
    char *found = strchr(str4, 'e');
    if (found != NULL) {
        printf("First 'e' found at position: %ld\n", found - str4);
    }
    
    found = strstr(str4, "cat");
    if (found != NULL) {
        printf("Substring 'cat' found at position: %ld\n", found - str4);
    }
}

void test() {
    char numStr[] = "12345";
    int number = atoi(numStr);
    long longNumber = atol(numStr);
    double doubleNumber = atof("123.45");
    
    printf("atoi('%s') = %d\n", numStr, number);
    printf("atol('%s') = %ld\n", numStr, longNumber);
    printf("atof('123.45') = %.2f\n", doubleNumber);
}

void test() {
    char sentence[] = "The quick brown fox";
    char *token;
    char delimiters[] = " ";
    
    printf("Original sentence: %s\n", sentence);
    printf("Tokens:\n");
    
    char sentenceCopy[50];
    strcpy(sentenceCopy, sentence);
    
    token = strtok(sentenceCopy, delimiters);
    while (token != NULL) {
        printf("  '%s'\n", token);
        token = strtok(NULL, delimiters);
    }
}

void test() {
    char manualStr[] = "abcdef";
    printf("Original: %s\n", manualStr);
    
    int len = strlen(manualStr);
    for (int i = 0; i < len / 2; i++) {
        char temp = manualStr[i];
        manualStr[i] = manualStr[len - 1 - i];
        manualStr[len - 1 - i] = temp;
    }
    printf("Reversed: %s\n", manualStr);
}

void test() {
    char *dynamicStr = malloc(20 * sizeof(char));
    if (dynamicStr != NULL) {
        strcpy(dynamicStr, "Dynamic string!");
        printf("%s\n", dynamicStr);
        free(dynamicStr); // Don't forget to free!
    }
}

int main() {
    test();
    return 0;
}
