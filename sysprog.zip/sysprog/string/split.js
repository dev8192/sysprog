function split_func(str){
    let result = []
    let idx = 0
    let word = ''    
    for (let i = 0; i < str.length; i++) {
        if (str[i] == ' '){
            result[idx] = word
            word = ''
            idx++
        } else {
            word += str[i]
        }
    }
    if (word.length > 0){
        result[idx] = word
    }
    
    return result
}
console.log(split_func('one two three'));
// console.log(split_func('one two three four five'));
// console.log(split_func('one'));
// console.log(split_func('   '));
