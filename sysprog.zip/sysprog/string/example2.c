#include <stdio.h>
#include <string.h>

/*
    Segfault
*/
void test() {
    char *msg = "Hello, world!";
    printf("'%s'\n", msg);
    msg[0] = 'h';
    printf("'%s'\n", msg);
}

void test1() {
    char msg[] = "Hello, world!";
    printf("'%s'\n", msg);
    msg[0] = 'h';
    printf("'%s'\n", msg);
}

void test2() {
    char name[32];
    printf("Enter your name: ");
    fgets(name, sizeof(name), stdin);
    printf("Your name: '%s'\n", name);
}

void test3() {
    char name[] = "Alice\n";
    name[strcspn(name, "\n")] = 0;
}

void test4() {
    char message[] = "Nice to meet you, ";
    const char *name = "Alice";
    strcat(message, name);
    strcat(message, "!");

    printf("%s\n", message);
}

void test1457() {
    char name[] = "Alice";
    char copy[50];
    strcpy(copy, name);
    printf("Copied name: %s\n", copy);
}

int main() {
    test();
    return 0;
}
