#include <stdio.h>

void test1() {
    int x = 42;
    int *ptr = &x;
    printf("'%p'\n", (void *) ptr);
    printf("'%p'\n", ptr);
    printf("'%p'\n", &x);
}

void test() {
    const char *fruits[3];
    printf("'%p'\n", fruits);
    printf("'%p'\n", fruits + 1);
    printf("'%p'\n", fruits + 2);

    fruits[0] = "apple";
    fruits[1] = "banana";
    fruits[2] = "kiwi";

    for (int i = 0; i < sizeof(fruits) / sizeof(fruits[0]); i++) {
        printf("%d '%s'\n", i, fruits[i]);
    }

    printf("'%s'\n", *(fruits + 0));
    printf("'%s'\n", *(fruits + 1));
    printf("'%s'\n", *(fruits + 2));
}

int main() {
    test();
    return 0;
}
