#include <stdio.h>
#include <stdint.h>

typedef struct {
    uint64_t h[8];
} sha512_ctx;

static void sha512_init(sha512_ctx *ctx) {
    ctx->h[0] = 0x6a09e667f3bcc908ULL;
    ctx->h[1] = 0xbb67ae8584caa73bULL;
    ctx->h[2] = 0x3c6ef372fe94f82bULL;
    ctx->h[3] = 0xa54ff53a5f1d36f1ULL;
    ctx->h[4] = 0x510e527fade682d1ULL;
    ctx->h[5] = 0x9b05688c2b3e6c1fULL;
    ctx->h[6] = 0x1f83d9abfb41bd6bULL;
    ctx->h[7] = 0x5be0cd19137e2179ULL;
}

int main() {
    sha512_ctx ctx;
    sha512_init(&ctx);
    for (int i = 0; i < (sizeof(ctx.h) / sizeof(uint64_t)); i++) {
        printf("%016lx\n", ctx.h[i]);
    };
}
