#include <stdio.h>

int sum1(int num1, int num2) {
    return num1 + num2;
}

void sum2(int num1, int num2, int *result) {
    *result = num1 + num2;
}

int main() {
    printf("%d\n", sum1(5, 10));
    
    int result;
    sum2(10, 15, &result);
    printf("%d\n", result);

    return 0;
}
