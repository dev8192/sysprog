#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char* name;
    int age;
} Person;

Person* create_person(const char* name, int age) {
    Person* p = malloc(sizeof(Person));
    if (!p) return NULL;

    p->name = malloc(strlen(name) + 1);
    if (!p->name) {
        free(p);
        return NULL;
    }
    strcpy(p->name, name);

    p->age = age;
    return p;
}

void destroy_person(Person* p) {
    if (p) {
        free(p->name);
        free(p);
    }
}

void person_greet(const Person* p) {
    if (p && p->name) {
        printf("Hello, my name is %s and I am %d years old.\n", p->name, p->age);
    }
}

void person_have_birthday(Person* p) {
    if (p) {
        p->age++;
    }
}

int main() {
    Person* alice = create_person("Alice", 30);

    person_greet(alice);
    person_have_birthday(alice);
    person_greet(alice);

    destroy_person(alice);
    return 0;
}
