#include <stdio.h>

int main() {
    const char* name = "Alice";
    int age = 30;
    printf("%s, %d\n", name, age);

    printf("%zu\n", sizeof(int));

    printf("\"%f\"\n", 3.14);
    printf("\"%10.2f\"\n", 3.14);
    printf("\"%.3f\"\n", 0.12345);

    printf("%d\n", 43981);
    printf("%x\n", 43981);

    printf("%d\n", 0xABCD);
    printf("%x\n", 0xABCD);
}
