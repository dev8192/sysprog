

#include <stdio.h>

int main() {
    int a = 10, b = 20;
    int max = (a > b) ? a : b;  // max = 20

    // Or in printf:
    printf("The larger number is %d.\n", (a > b) ? a : b);
}

