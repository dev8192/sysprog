
#define SHA_LONG64 unsigned long

