/*
This file contains multiple examples
with one main() function
*/
#include <stdio.h>

void test1() {
    printf("Test 1\n");
}

void test() {
    printf("Test 2\n");
}

void test3() {
    printf("Test 3\n");
}

int main() {
    test();
    return 0;
}
