/*
This file contains multiple examples
using preprocessor directives
*/
#include <stdio.h>

#if 1
int main() {
    printf("Test 11\n");
    return 0;
}
#endif

#if 0
int main() {
    printf("Test 22\n");
    return 0;
}
#endif

#if 0
int main() {
    printf("Test 33\n");
    return 0;
}
#endif
