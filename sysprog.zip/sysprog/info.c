/*
********** Info **********

https://en.cppreference.com/w/c/language.html



********** install gcc **********

$ sudo apt install gcc

********** How to compile programs **********

$ gcc hello.c -o hello
$ ./hello


*/