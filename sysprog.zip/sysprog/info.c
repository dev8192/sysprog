/*
********** Info **********

https://en.cppreference.com/w/c/language.html

********** How to compile programs **********

$ sudo apt install gcc
$ gcc hello.c -o hello
$ ./hello


*/