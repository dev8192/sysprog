/*
    echo hello | ./a.out
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char input[1024];
    if (fgets(input, sizeof(input), stdin)) {
        input[strcspn(input, "\r\n")] = 0;
        printf("'%d' '%s'\n", strlen(input), input);
    }
    return 0;
}
