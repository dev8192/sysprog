#include <stdio.h>
#include <math.h>

void print_byte(int b7, int b6, int b5, int b4, int b3, int b2, int b1, int b0) {
    int result = (int) b7 * pow(2, 7) +
    b6 * pow(2, 6) +
    b5 * pow(2, 5) +
    b4 * pow(2, 4) +
    b3 * pow(2, 3) +
    b2 * pow(2, 2) +
    b1 * pow(2, 1) +
    b0 * pow(2, 0);
    printf("%x\n", result);
}

void test() {
    printf("%x\n", 0);
    print_byte(0, 0, 0, 0, 0, 0, 0, 0); // 0b0000_0000
    printf("%x\n", 127);
    print_byte(0, 1, 1, 1, 1, 1, 1, 1); // 0b0111_1111
    printf("%x\n", 0xa5);
    print_byte(1, 0, 1, 0, 0, 1, 0, 1); // 0b0111_1111
    printf("%x\n", 255);
    print_byte(1, 1, 1, 1, 1, 1, 1, 1); // 0b1111_1111
}

int main() {
    test();    
    return 0;
}
