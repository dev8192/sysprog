#include <stdio.h>

int main() {

    int num;

    printf("Введите число:");
    scanf("%d", &num);

    if(num % 2 == 0) {
        printf("Число чётное\n");
    } else {
        printf("Число нечётное\n");
    }

    return 0;
}