#include <stdio.h>

typedef struct {
    char* name;
    int age;
} Person;

int main() {
    Person alice = {"Alice", 30};
    Person *alice_ptr = &alice;

    printf("%s, %d\n", alice.name, alice.age);
    printf("%s, %d\n", alice_ptr->name, alice_ptr->age);

    alice.age++;
    printf("%s, %d\n", alice.name, alice.age);
    printf("%s, %d\n", alice_ptr->name, alice_ptr->age);

    // alice_ptr->age++;
    ++alice_ptr->age;
    printf("%s, %d\n", alice.name, alice.age);
    printf("%s, %d\n", alice_ptr->name, alice_ptr->age);
    
    return 0;
}
